package com.example.crud;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Settings_User extends AppCompatActivity {
int imperial_checked=0;
int metrric_checked =0;
int   w=0;
    int   b=0;
    int   t=0;
    int   d=0;

    private DatabaseReference df;
    String   username;
    String  mode;
    String  sys;
    TextView m,s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings__user);
        Intent intent = getIntent();
        username = intent.getStringExtra("Username");

        Toast.makeText(this, username, Toast.LENGTH_SHORT).show();
        df = FirebaseDatabase.getInstance().getReference("Settings");
        m=(TextView)findViewById(R.id.measure);
        s=(TextView)findViewById(R.id.transport);


display();
    }
    void display(){

        DatabaseReference dff = FirebaseDatabase.getInstance().getReference().child("Settings").child(username);
        dff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try{
                    String name = dataSnapshot.child("transport").getValue().toString();
                //    String password =dataSnapshot.child("password").getValue().toString();

                  //  if(p.getText().toString().equals(password)&&name.equals(n.getText().toString())){
                       Toast.makeText(Settings_User.this, name, Toast.LENGTH_SHORT).show();
                      //  transfer(1);
                      //  n.setText("");
                      //  p.setText("");


                    }catch(Exception a){


                 //   transfer(0);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }








    public void update_settings(View view) {
        if(view.getId()==R.id.imperial)
        {
            imperial_checked=1;
            metrric_checked=0;
            sys="imperial";
            Toast.makeText(this, "imperial", Toast.LENGTH_SHORT).show();
        }

        if(view.getId()==R.id.metric)
        {
            imperial_checked=0;
            metrric_checked=1;
            sys="metric";
        }
        if(view.getId()==R.id.walking)
        {
            w=1;
            t=0;
            d=0;
            b=0;
            mode="walking";
        }
        if(view.getId()==R.id.driving)
        {
            w=0;
            t=0;
            d=1;
            b=0;
            mode="driving";
        }
        if(view.getId()==R.id.transit)
        {
            w=0;
            t=1;
            d=0;
            b=0;
            mode="transit";
        }
        if(view.getId()==R.id.bicycling)
        {
            w=0;
            t=0;
            d=0;
            b=1;
            mode="bicycling";
        }
//DDELETE
try{
String temp=username;
    DatabaseReference D = FirebaseDatabase.getInstance().getReference("Settings").child(username);
    D.removeValue();
    {
        Toast.makeText(this, sys+"{", Toast.LENGTH_SHORT).show();
    }
    Settings set = new Settings(temp,mode,sys);

    df.child(temp).setValue(set);


    Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();

}catch(Exception e){
    Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();

}


    }

    public void do_now(View view) {



    }
}
