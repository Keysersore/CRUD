package com.example.crud;

public class Settings {


    String username;

    String transport;
    String measurment;

    public Settings(String username, String transport, String measurment) {
        this.username = username;
        this.transport = transport;
        this.measurment = measurment;
    }

    public String getUsername() {
        return username;
    }

    public String getTransport() {
        return transport;
    }

    public String getMeasurment() {
        return measurment;
    }
}
