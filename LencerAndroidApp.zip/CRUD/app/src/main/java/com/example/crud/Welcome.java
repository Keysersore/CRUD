package com.example.crud;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Welcome extends AppCompatActivity {
    public static String []Options={"Settings","Targets","About","Profile","Logs","Pictures"};
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);


        Intent intent = getIntent();
        username   = intent.getStringExtra("Username");

        Toast.makeText(this,     username , Toast.LENGTH_SHORT).show();

        ArrayList<String> list = new ArrayList<String>();
        for(int x=0;x<Options.length;x++){
            list.add(Options[x]);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
        ListView listView = (ListView)findViewById(R.id.list_items);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(Welcome.this, Options[i].toString(), Toast.LENGTH_SHORT).show();
                transfer(i,username);

            }
        });
    }
    public void transfer (int list_item,String user){
        if(list_item==0){
            Intent intent = new Intent(this,Settings_User.class);
            intent.putExtra("Username",user);


            startActivity(intent);
        }
        if(list_item==1){
            Intent intent = new Intent(this,BeginJourney.class);
            intent.putExtra("Username",user);


            startActivity(intent);
        }


    }

    public void shut(View view) {
        System.exit(0);
    }


    public void logout(View view) {
        System.exit(1);
    }
}
